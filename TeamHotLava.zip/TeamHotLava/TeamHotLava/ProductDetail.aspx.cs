﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ProductDetail : System.Web.UI.Page
{
    string connectionString = WebConfigurationManager.ConnectionStrings["Prods"].ConnectionString;
    string[] array = new string[6];

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString != null)
        {
            string queryStringID = Request.QueryString["id"];
            string selectSQL = "SELECT * FROM Products WHERE [Product ID] = " + queryStringID;
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(selectSQL, con);
            SqlDataReader reader;
            

            try
            {
                con.Open();
                reader = cmd.ExecuteReader();
                //for each item, display the authors name and store the unique id in the value property
                while (reader.Read())
                {
                    array[0] = reader["Image URL"].ToString();
                    array[1] = reader["Product Description"].ToString();
                    array[2] = reader["Product Name"].ToString();
                    array[3] = reader["Price"].ToString();
                    array[4] = reader["Product ID"].ToString();
                }
                reader.Close();
            }
            catch (Exception err)
            {
                lblResults.Text = "Error reading list of names. " + err.Message;
                lblResults.Visible = true;
            }
            finally
            {
                con.Close();
            }

            mainImage.ImageUrl = array[0];
            headThreeTagOne.InnerText = array[2];
            headFourTagOne.InnerText = "$"+array[3]+".00";
            paraTagOne.InnerText = array[1];
        }
    }

    protected void btnAddToCart_Click(object sender, EventArgs e)
    {
        Cart c;

        if (Session["Cart"] != null)
        {
            c = (Cart)Session["Cart"];
        }
        //if Cart does not exist in session, create a new one
        else
        {
            c = new Cart();
        }


        //Add the item to the Cart using the AddItem method

        int prodID = Convert.ToInt16(array[4]);
        decimal price = Convert.ToDecimal(array[3]);
        int quantity = Convert.ToInt16(txtQuantity.Text);
        c.AddItem(prodID, array[2], price, quantity, array[0]);
        Session["Cart"] = c;
    }
}