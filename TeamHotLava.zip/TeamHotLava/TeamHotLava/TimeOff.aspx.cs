﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPages_TimeOff : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void btnRequest_Click(object sender, EventArgs e)
    {
        //Get connection string
        string constring = WebConfigurationManager.ConnectionStrings["HotLava"].ConnectionString;
        //(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\HotLava.mdf;Integrated Security=True

        //Lets get a connection
        SqlConnection con = new SqlConnection(constring);

        //Instantiate a sql command
        SqlCommand cmd = new SqlCommand("TimeOffRequestInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        //Add parameters
        cmd.Parameters.AddWithValue("@StaffID", ddlStaff.SelectedValue);
        cmd.Parameters.AddWithValue("@RequestedDayOff", cldrRequestDay.SelectedDate);
        cmd.Parameters.AddWithValue("@HoursPaid", Convert.ToDecimal(txtHours.Text));
        cmd.Parameters.AddWithValue("@Reason", txtReason.Text);


        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        Response.Redirect("TimeOffHistory.aspx");
    }
}