﻿using System;
using System.Collections.Generic;


public class Cart
{
    
    private List<CartItem> items = new List<CartItem>();
    
    public List<CartItem> Items
    {
        get { return items; }
    }
    
    public bool HasItems
    {
        get
        {
            if (items.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
    
    public void AddItem(int id, string name, decimal price, int quantity)
    {

        bool isInCart = false;
        CartItem item = null;

        foreach (CartItem c in items)
        {
            if (c.ItemId == id)
            {
                isInCart = true;
                item = c;
            }
        }
        
        if (isInCart)
        {
            item.Quantity += quantity;
        }
        else 
        {
            CartItem ci = new CartItem(id, name, price, quantity);
            Items.Add(ci);
        }


    }

    
    public void AddItem(int id, string name, decimal price, int quantity, string imagePath)
    {

        bool isInCart = false;
        CartItem item = null;

        foreach (CartItem c in items)
        {
            if (c.ItemId == id)
            {
                isInCart = true;
                item = c;
            }
        }

        if (isInCart)
        {
            item.Quantity += quantity;
        }
        else 
        {
            
            CartItem ci = new CartItem(id, name, price, quantity, imagePath);
            
            Items.Add(ci);
        }


    }
    

    public void RemoveItem(int id)
    {
        CartItem itemToRemove = null;
        
        foreach (CartItem ci in Items)
        {
            if (ci.ItemId == id)
                itemToRemove = ci;

        }

        if (itemToRemove != null)
            Items.Remove(itemToRemove);
    }
    
    public void UpdateQuantity(int id, int newQuantity)
    {
        CartItem itemToUpdate = null;
        
        foreach (CartItem ci in Items)
        {
            if (ci.ItemId == id)
                itemToUpdate = ci;

        }

        if (itemToUpdate != null)
            itemToUpdate.Quantity = newQuantity;
    }
    
    public decimal GetSubTotal()
    {
        decimal subtotal = 0;
        foreach (CartItem ci in Items)
        {
            subtotal += ci.ExtendedPrice;
        }
        return subtotal;

    }

    
    public decimal GetShipping()
    {
        return GetSubTotal() * 0.15M;
    }

    
    public decimal GetTotal()
    {
        return GetSubTotal() + GetShipping();

    }

    
    public Cart()
    {

    }




}
