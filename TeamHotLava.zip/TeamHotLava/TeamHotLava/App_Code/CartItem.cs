﻿using System;


public class CartItem
{
    
    private int itemId;
    private string name;
    private decimal price;
    private int quantity;
    private string imagePath;
    
    public int ItemId
    {
        get { return itemId; }
    }

    public string Name
    {
        get { return name; }
    }

    public decimal Price
    {
        get { return price; }
    }

    public int Quantity
    {
        get { return quantity; }
        set { if (value >= 1) quantity = value; }
    }

    public string ImagePath
    {
        get { return imagePath; }
    }
    public decimal ExtendedPrice
    {
        get { return price * quantity; }
    }
    
    public CartItem(int paramID, string paramName, decimal paramPrice, int paramQuantity)
    {
        this.itemId = paramID;
        this.name = paramName;
        this.price = paramPrice;
        this.Quantity = paramQuantity;
    }

    public CartItem(int paramID, string paramName, decimal paramPrice, int paramQuantity, string paramImage)
    {
        this.itemId = paramID;
        this.name = paramName;
        this.price = paramPrice;
        this.Quantity = paramQuantity;
        this.imagePath = paramImage;
    }
}
