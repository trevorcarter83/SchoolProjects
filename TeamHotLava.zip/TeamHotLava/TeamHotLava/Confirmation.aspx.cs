﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class teamhotlava_project_Confirmation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        string[] userDetails = (string [])Session["userDetails"];
        if(userDetails != null)
        {
            nameHeader.InnerText = "Thank you "+userDetails[0]+"!";
            address.InnerText = "Your items will shipped to this address: " + userDetails[1] + " and will arrive in 5-7 business days.";
        }
        
    }
}