﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class teamhotlava_project_Checkout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Dictionary<int, String> myMonths = new Dictionary<int, String>();
        Dictionary<int, String> myYears = new Dictionary<int, String>();
        myMonths.Add(1, "Jan");
        myMonths.Add(2, "Feb");
        myMonths.Add(3, "Mar");
        myMonths.Add(4, "Apr");
        myMonths.Add(5, "May");
        myMonths.Add(6, "Jun");
        myMonths.Add(7, "Jul");
        myMonths.Add(8, "Aug");
        myMonths.Add(9, "Sep");
        myMonths.Add(10, "Oct");
        myMonths.Add(11, "Nov");
        myMonths.Add(12, "Dec");

        myYears.Add(1, "2018");
        myYears.Add(2, "2019");
        myYears.Add(3, "2020");
        myYears.Add(4, "2021");
        myYears.Add(5, "2022");
        myYears.Add(6, "2023");
        myYears.Add(7, "2024");
        myYears.Add(8, "2025");
        myYears.Add(9, "2026");
        myYears.Add(10, "2027");
        myYears.Add(11, "2028");
        myYears.Add(12, "2029");
        myYears.Add(13, "2030");

        ddlMonths.DataSource = myMonths;
        ddlYears.DataSource = myYears;
        
        ddlMonths.DataTextField = "Value";
        ddlMonths.DataValueField = "Key";

        ddlYears.DataTextField = "Value";
        ddlYears.DataValueField = "Key";

        ddlMonths.DataBind();
        ddlYears.DataBind();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Confirmation.aspx");
        string[] userDetails = new string[8];
        userDetails[0] = TextBox9.Text;
        userDetails[1] = TextBox10.Text;
        userDetails[2] = TextBox11.Text;
        userDetails[3] = TextBox12.Text;
        userDetails[4] = TextBox13.Text;
        userDetails[5] = TextBox14.Text;
        userDetails[6] = TextBox15.Text;
        userDetails[7] = TextBox16.Text;

        Session["userDetails"] = userDetails;
    }

    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if(CheckBox1.Checked)
        {
            TextBox9.Text = TextBox1.Text;
            TextBox10.Text = TextBox2.Text;
            TextBox11.Text = TextBox3.Text;
            TextBox12.Text = TextBox4.Text;
            TextBox13.Text = TextBox5.Text;
            TextBox14.Text = TextBox6.Text;
            TextBox15.Text = TextBox7.Text;
            TextBox16.Text = TextBox8.Text;
        }
    }
}