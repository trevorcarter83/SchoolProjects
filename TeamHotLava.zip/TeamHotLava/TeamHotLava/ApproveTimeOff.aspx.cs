﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPages_ApproveTimeOff : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


    }

    protected void btnApprove_Click(object sender, EventArgs e)
    {
        int Approve = 1;

        //Get connection string
        string constring = WebConfigurationManager.ConnectionStrings["HotLava"].ConnectionString;
        //(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\HotLava.mdf;Integrated Security=True

        //Lets get a connection
        SqlConnection con = new SqlConnection(constring);

        //Instantiate a sql command
        SqlCommand cmd = new SqlCommand("TimeOffRequestApproveUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;

        //Add parameters
        cmd.Parameters.AddWithValue("@TimeOffRequestID", ddlApprove.SelectedValue);
        cmd.Parameters.AddWithValue("@IsApproved", Approve);

        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        Response.Redirect("ApproveTimeOff.aspx");
    }

    protected void btnDeny_Click(object sender, EventArgs e)
    {
        int Approve = 0;

        //Get connection string
        string constring = WebConfigurationManager.ConnectionStrings["HotLava"].ConnectionString;
        //(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\HotLava.mdf;Integrated Security=True

        //Lets get a connection
        SqlConnection con = new SqlConnection(constring);

        //Instantiate a sql command
        SqlCommand cmd = new SqlCommand("TimeOffRequestApproveUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;

        //Add parameters
        cmd.Parameters.AddWithValue("@TimeOffRequestID", ddlApprove.SelectedValue);
        cmd.Parameters.AddWithValue("@IsApproved", Approve);

        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        Response.Redirect("ApproveTimeOff.aspx");
    }

    protected void ddlApprove_SelectedIndexChanged(object sender, EventArgs e)
    {
        string query = "SELECT Reason FROM TimeOffRequests WHERE TimeOffRequestID = " + ddlApprove.SelectedValue;

        //Get connection string
        string constring = WebConfigurationManager.ConnectionStrings["HotLava"].ConnectionString;
        //(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\HotLava.mdf;Integrated Security=True

        //Lets get a connection
        SqlConnection con = new SqlConnection(constring);

        SqlCommand cmd = new SqlCommand(query, con);

        con.Open();
        lblReason.Text = cmd.ExecuteScalar().ToString();

        con.Close();

    }
}