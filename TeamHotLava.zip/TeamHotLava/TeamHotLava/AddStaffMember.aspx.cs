﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPages_AddStaffMember : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //Get connection string
        string constring = WebConfigurationManager.ConnectionStrings["HotLava"].ConnectionString;
        //(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\HotLava.mdf;Integrated Security=True

        //Lets get a connection
        SqlConnection con = new SqlConnection(constring);

        //Instantiate a sql command
        SqlCommand cmd = new SqlCommand("StaffMemberInsert",con);
        cmd.CommandType = CommandType.StoredProcedure;

        //Add parameters
        cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
        cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
        cmd.Parameters.AddWithValue("@DateOfBirth", cldrDateOfBirth.SelectedDate);
        cmd.Parameters.AddWithValue("@Department", ddlDepartment.SelectedValue);
        cmd.Parameters.AddWithValue("@IsManager", Convert.ToInt16(rblManager.SelectedValue));
        cmd.Parameters.AddWithValue("@IsActive", Convert.ToInt16(rblActive.SelectedValue));
        cmd.Parameters.AddWithValue("@HireDate", cldrHire.SelectedDate);

        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        Response.Redirect("Staff.aspx");

    }
}