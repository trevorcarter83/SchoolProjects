﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPages_StaffDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Get active staff count
        string query = "SELECT COUNT(*) FROM Staff WHERE IsActive = 1";
        int count = 0;

        //Get connection string
        string constring = WebConfigurationManager.ConnectionStrings["HotLava"].ConnectionString;
        //(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\HotLava.mdf;Integrated Security=True

        //Lets get a connection
        SqlConnection con = new SqlConnection(constring);

        SqlCommand cmd = new SqlCommand(query, con);

        con.Open();
        count = (int)cmd.ExecuteScalar();
        con.Close();

        lblActive.Text = count.ToString();

        //Get pending time off request count
        string query2 = "SELECT COUNT(*) FROM TimeOffRequests WHERE IsApproved IS NULL";
        int count2 = 0;

        SqlCommand cmd2 = new SqlCommand(query2, con);

        con.Open();
        count2 = (int)cmd2.ExecuteScalar();
        con.Close();

        lblNotification.Text = count2.ToString();
    }
}