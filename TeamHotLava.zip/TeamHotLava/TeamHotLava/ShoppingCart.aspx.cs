﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class teamhotlava_project_ShoppingCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        Cart c;
        if (Session["Cart"] != null)
        {
            c = (Cart)Session["Cart"];
            GridView1.DataSource = c.Items;
            lblSubtotal.Text = "Subtotal: " + String.Format("{0:c}", c.GetSubTotal());
            lblShipping.Text = "Shipping: " + String.Format("{0:c}", c.GetShipping());
            lblTotal.Text = "Total: " + String.Format("{0:c}", c.GetTotal());
            if (!IsPostBack)
                GridView1.DataBind();
        }
        else
        {
            emptyCart.InnerText = "Your cart is empty.";
            lblSubtotal.Text = "";
            lblSubtotal.Visible = false;
            lblShipping.Text = "";
            lblShipping.Visible = false;
            lblTotal.Text = "";
            lblTotal.Visible = false;
        }
        GridView1.DataBind();
    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataBind();
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Cart c;
        int[] intArray = new int[50];
        int counter = 0;

        if (Session["Cart"] != null)
        {
            c = (Cart)Session["Cart"];
        }
        //if Cart does not exist in session, create a new one
        else
        {
            c = new Cart();
        }

        foreach(CartItem ci in c.Items)
        {
            intArray[counter] = ci.ItemId;
            counter++;
        }

        TextBox txtQuantity = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtQuantity");
        int qty = Convert.ToInt16(txtQuantity.Text);
        int itemId = intArray[e.RowIndex];
        c.UpdateQuantity(itemId, qty);

        GridView1.EditIndex = -1;

    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Cart c;
        int[] intArray = new int[50];
        int counter = 0;

        if (Session["Cart"] != null)
        {
            c = (Cart)Session["Cart"];
        }
        //if Cart does not exist in session, create a new one
        else
        {
            c = new Cart();
        }

        foreach (CartItem ci in c.Items)
        {
            intArray[counter] = ci.ItemId;
            counter++;
        }
        
        int itemId = intArray[e.RowIndex];
        c.RemoveItem(itemId);
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("CheckoutPath.aspx");
    }
}