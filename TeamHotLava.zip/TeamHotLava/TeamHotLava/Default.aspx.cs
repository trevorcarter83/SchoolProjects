﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    string connectionString = WebConfigurationManager.ConnectionStrings["Prods"].ConnectionString;


    protected void Page_Load(object sender, EventArgs e)
    {
        Random rnd = new Random();
        int one = rnd.Next(1, 25);
        int two = rnd.Next(1, 25); ;
        int three = rnd.Next(1, 25); ;
        int four = rnd.Next(1, 25); ;
        int five = rnd.Next(1, 25); ;
        int six = rnd.Next(1, 25); ;



        while (two == one)
            two = rnd.Next(1, 25);

        while (three == one || three == two)
            three = rnd.Next(1, 25);

        while (four == one || four == two || four == three)
            four = rnd.Next(1, 25);

        while (five == one || five == two || five == three || five == four)
            five = rnd.Next(1, 25);

        while (six == one || six == two || six == three || six == four || six == five)
            six = rnd.Next(1, 25);

        string selectSQL = "SELECT * FROM Products WHERE [Product ID] = " + one + " or [Product ID] = " + two + " or " +
            "[Product ID] = "+three + "or [Product ID] = " + four + " or [Product ID] = " + five + " or [Product ID] = " + six + ";";

        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand(selectSQL, con);
        SqlDataReader reader;
        string[,] array = new string[6, 6];

        try
        {
            con.Open();
            reader = cmd.ExecuteReader();
            int counter = 0;
            //for each item, display the authors name and store the unique id in the value property
            while (reader.Read())
            {
                
                array[counter,0] = reader["Image URL"].ToString();
                array[counter, 1] = reader["Product Description"].ToString();
                array[counter, 2] = reader["Product Name"].ToString();
                array[counter, 3] = reader["Price"].ToString();
                array[counter, 4] = reader["Product ID"].ToString();
                counter++;
            }
            reader.Close();
        }
        catch (Exception err)
        {
            lblResults.Text = "Error reading list of names. " + err.Message;
        }
        finally
        {
            con.Close();
        }

        //set card one
        imgControlOne.Attributes["src"] = array[0, 0];
        anchorTagOne.Attributes["href"] = "./ProductDetail.aspx?id=" + array[0, 4];
        header5TagOne.InnerText = "$" + array[0, 3]+".00";
        paraTagOne.InnerText = array[0, 1];
        anchorTagOne.InnerText = array[0, 2];
        imgAnchorTagOne.Attributes["href"] = "./ProductDetail.aspx?id="+array[0,4];

        //set card two
        img1.Attributes["src"] = array[1, 0];
        a2.Attributes["href"] = "./ProductDetail.aspx?id=" + array[1, 4];
        h1.InnerText = "$" + array[1, 3] + ".00";
        p1.InnerText = array[1, 1];
        a2.InnerText = array[1, 2];
        A1.Attributes["href"] = "./ProductDetail.aspx?id=" + array[1, 4];

        //set card three
        img2.Attributes["src"] = array[2, 0];
        a4.Attributes["href"] = "./ProductDetail.aspx?id=" + array[2, 4];
        h2.InnerText = "$" + array[2, 3] + ".00";
        p2.InnerText = array[2, 1];
        a4.InnerText = array[2, 2];
        A3.Attributes["href"] = "./ProductDetail.aspx?id=" + array[2, 4];

        //set card four
        img3.Attributes["src"] = array[3, 0];
        a6.Attributes["href"] = "./ProductDetail.aspx?id=" + array[3, 4];
        h3.InnerText = "$" + array[3, 3] + ".00";
        p3.InnerText = array[3, 1];
        a6.InnerText = array[3, 2];
        A5.Attributes["href"] = "./ProductDetail.aspx?id=" + array[3, 4];

        //set card five
        img4.Attributes["src"] = array[4, 0];
        a8.Attributes["href"] = "./ProductDetail.aspx?id=" + array[4, 4];
        h4.InnerText = "$" + array[4, 3] + ".00";
        p4.InnerText = array[4, 1];
        a8.InnerText = array[4, 2];
        A7.Attributes["href"] = "./ProductDetail.aspx?id=" + array[4, 4];

        //set card six
        img5.Attributes["src"] = array[5, 0];
        a10.Attributes["href"] = "./ProductDetail.aspx?id=" + array[5, 4];
        h5.InnerText = "$" + array[5, 3] + ".00";
        p5.InnerText = array[5, 1];
        a10.InnerText = array[5, 2];
        A9.Attributes["href"] = "./ProductDetail.aspx?id=" + array[5, 4];
    }
    

}