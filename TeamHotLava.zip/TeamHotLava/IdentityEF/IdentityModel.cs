﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using System.Web;
using System;

/// <summary>
/// Classes to manage and extend the base classes of the Identity Model
/// </summary>
// You can add User data for the user by adding more properties to your User class, please visit https://go.microsoft.com/fwlink/?LinkID=317594 to learn more.

namespace IdentityEF
{

    //The ApplicationUser class extends the base IdentityUser class that represents a user of our application. 
    //We can add additional properties to this class to track additional user profile variables.
    public class ApplicationUser : IdentityUser
    {


    }

    //The ApplicationDbContext class extends the base IdentityDbContext class.  
    //This class acts as an interface between the entity objects (such as the ApplicationUser) and the Identity database that will be created.
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("IdentityDB")
        {
        }
    }

    //The UserManager class extends the base UserManager class provided by ASP.NET Identity.
    //This extension is simply for convenience.
    //It calls the constructor of the base UserManager class, passing in new instantiations of the UserStore object (that represents the database)
    //and the the ApplicationDBContext.
    //In this way, the UserManager will be preconfigured to work with our custom ApplicationUser and ApplicationDbContext objects.
    public class UserManager : UserManager<ApplicationUser>
    {
        public UserManager()
            : base(new UserStore<ApplicationUser>(new ApplicationDbContext()))
        {
        }
    }


    //Similar to the UserManager class above, the RoleManager class provides a pre-configured RoleManager that extends the base RoleManager class
    public class RoleManager : RoleManager<IdentityRole>
    {

        public RoleManager()
            : base(new RoleStore<IdentityRole>(new ApplicationDbContext()))
        { }
    }
}

